# AIGMos CW Clean Staging Pass 2 / 158

This pass is the first **active-tree semantic reconciliation** over the supplied full base specification.

## What changed

- All **53 duplicate canonical contract-ID groups** were reconciled into one unlocked definition per canonical identity.
- Source duplicate files are preserved under `reconciliation/source_duplicates/**`.
- No duplicate source was selected by path, mtime, load order or newest-wins.
- Differing string clauses were retained in the merged definition instead of discarded.
- The remaining five Topic collisions were resolved semantically.
- All five operation collisions were resolved.
- Root Contract Format bootstrap order now points to the actual supplied Master:
  `canonical/json/master/00_Canonical_Master_1_4.json`
- The modified root is intentionally `unlocked` pending validation.
- Contract Format status/source-role child definitions were aligned to the locked source root's declared enum sets.

## Collision result

- active contract files: **1486**
- duplicate contract IDs after pass: **0**
- duplicate Topic IDs after pass: **0**
- duplicate behavior IDs after pass: **0**

## Remaining bootstrap blocker

The supplied Canonical Master says it must declare active canonical roots, and Core Bootstrap requires those roots to be explicit.

The supplied Master does **not** yet contain an explicit active-root list.

This pass therefore records:

`MASTER_ACTIVE_ROOT_DECLARATIONS_MISSING`

and does not infer roots from directories.

## Reference closure

Strong canonical-reference fields:
- resolved occurrences: **5146**
- unresolved occurrences: **2209**
- unique unresolved target IDs: **398**

See `reconciliation/reports/REFERENCE_CLOSURE_TRIAGE.json`.

## Next order

1. Define the Master active-root set explicitly from the semantic architecture.
2. Resolve the remaining strong-reference target gaps.
3. Re-run Topic inheritance/membership coverage.
4. Run full Contract Format 1.4 hard-gate validation.
5. Then simplify reconciled string clauses and relocate neutral `reconciled/contracts/**` paths only as presentation/repository hygiene.
6. Only after that evaluate lock eligibility.

This tree is collision-free for canonical contract, Topic and behavior identities, but it is **not yet lock-ready**.
