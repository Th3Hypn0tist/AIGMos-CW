#!/usr/bin/env python3
"""
Pass 7 validator profile summary.

The full executed validator is represented by the PASS7_* machine reports in
reconciliation/reports. This file documents the decisive profile:

1. Load root Contract Format.
2. Load exact Master.
3. Scan canonical/json recursively as candidates only.
4. Select exact Master.active_contract_refs + Master.
5. Validate Contract Format shape and nested required fields.
6. Validate global and owner-scoped identity uniqueness.
7. Resolve ordinary, structure and Topic refs exactly.
8. Validate Topic cycles, coverage and Outsiders.
9. Validate Flow owner/entry/exit/action/cause/next/subflow/resume refs.
10. Treat unresolved non-null Flow *_ref/_refs symbolic tokens as semantic gaps.
11. Validate JSON parse/serialize/parse preservation.
12. Keep semantic-only hard gates REVIEW_REQUIRED until independently proven.
13. lock_eligible only when blocking findings == 0 and review-required gates == 0.
