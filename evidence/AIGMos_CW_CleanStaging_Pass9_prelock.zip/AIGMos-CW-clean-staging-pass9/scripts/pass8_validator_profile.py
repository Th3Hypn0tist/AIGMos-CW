#!/usr/bin/env python3
"""
Pass 8 decisive validation profile:

- Contract Format shape/type validation
- active Master membership
- global + owner-scoped identity uniqueness
- exact ordinary/structure/Topic reference closure
- Topic cycles/coverage/Outsider checks
- Flow owner/entry/exit/action/cause/next/subflow/resume closure
- every non-null Flow actor/data/target/condition/payload/result/error ref resolves
  to an explicit semantic identity
- JSON representation roundtrip
- semantic-only gates remain REVIEW_REQUIRED until separately proven

Flow symbol normalization:
    FSYM = SHA256(owner_contract_id, flow_ref_field, exact_source_literal)[:20]
This creates an exact owner-scoped member identity without inferring additional meaning.
