#!/usr/bin/env python3
"""
Pass 9 semantic proof profile.

Proof surfaces:
1. Topic provenance:
   source Topic identities vs reconciliation-created identities with explicit provenance.
2. Topic nonauthority:
   no Topic id is an endpoint of structure ownership/authority/dependency/containment
   or Flow causal/action edges.
3. Topic composition duplication:
   compare owner-qualified direct trace identities between composing and composed Topics.
4. Topic composition causality/leak:
   composition refs are never consumed as Flow/structure causal or authority edges.
5. Semantic-model roundtrip:
   explicit family-by-family normalized semantic read model -> serialized model ->
   reconstructed canonical semantic object.
6. Bidirectional traceability:
   forward edge index + reverse target index with exact contract/json-path provenance.
7. Scope/structure consistency:
   evaluate actual typed ownership/containment/authority/dependency surfaces rather
   than guessing equivalence from prose strings.
