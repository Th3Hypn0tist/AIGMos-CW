# AIGMos 1.4 Review Builder

This package creates a clean parallel Contract Format 1.4 review tree from an
existing AIGMos_docs checkout.

It does **not** modify `canonical/json`.

## Run

From anywhere:

    python build_review_tree.py /path/to/AIGMos_docs

The output is created at:

    /path/to/AIGMos_docs/AIGMos_canonical_1.4_review/

Review:

    AIGMos_canonical_1.4_review/migration_manifest.json
    AIGMos_canonical_1.4_review/README_REVIEW.md
    AIGMos_canonical_1.4_review/canonical/json/

## Migration behavior

- replaces the review-tree format root with Contract Format 1.4.0
- normalizes active canonical contracts to `format_version: 1.4`
- marks affected active contracts `unlocked`
- ensures required 1.4 structural dimensions exist
- adds the native `topics` dimension if absent
- NEVER invents Topic membership from directory paths
- reports missing Topic classification as a hard review gap
- preserves legacy/history without promoting it to active authority

This is deliberately a review-tree builder, not an automatic semantic fixer.
