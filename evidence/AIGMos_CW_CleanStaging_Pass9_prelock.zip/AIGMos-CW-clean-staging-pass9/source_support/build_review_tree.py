#!/usr/bin/env python3
"""
AIGMos Canonical Contract Format 1.4 review-tree builder.

This tool NEVER modifies the source canonical tree.
It creates a clean parallel review tree and a machine-readable migration manifest.

Usage:
    python build_review_tree.py /path/to/AIGMos_docs

Output:
    /path/to/AIGMos_docs/AIGMos_canonical_1.4_review/
"""

from __future__ import annotations
import json
import shutil
import sys
from copy import deepcopy
from pathlib import Path

FORMAT_VERSION = "1.4"
FORMAT_ROOT_VERSION = "1.4.0"
ACTIVE_STATUSES = {"locked", "unlocked"}
HISTORICAL_STATUSES = {"superseded", "deprecated"}

REQUIRED_TOP_LEVEL = [
    "format",
    "identity",
    "status",
    "source_role",
    "purpose",
    "scope",
    "members",
    "structure",
    "topics",
    "behavior",
    "semantics",
    "constraints",
    "references",
    "prose",
]

def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")

def ensure_shape(doc: dict):
    doc.setdefault("format", {})
    doc["format"]["contract_format"] = "AIGMOS_CANONICAL_CONTRACT"
    doc["format"]["format_version"] = FORMAT_VERSION

    doc.setdefault("identity", {})
    doc.setdefault("status", "unlocked")
    doc.setdefault("source_role", "definition")
    doc.setdefault("purpose", "")
    doc.setdefault("scope", {})
    doc["scope"].setdefault("owns", [])
    doc["scope"].setdefault("does_not_own", [])
    doc.setdefault("members", [])

    doc.setdefault("structure", {})
    for k in ("containment", "relations", "ownership", "authority", "dependencies"):
        doc["structure"].setdefault(k, [])

    # 1.4 native grouping dimension.
    # IMPORTANT: we do NOT invent Topic classification.
    doc.setdefault("topics", [])

    doc.setdefault("behavior", {})
    for k in ("states", "interfaces", "operations", "events", "flows"):
        doc["behavior"].setdefault(k, [])

    doc.setdefault("semantics", {})
    doc.setdefault("constraints", {})
    doc["constraints"].setdefault("invariants", [])
    doc["constraints"].setdefault("hard_gates", [])
    doc.setdefault("references", [])

    doc.setdefault("prose", {})
    doc["prose"].setdefault("summary", None)
    doc["prose"].setdefault("notes", [])

    return doc

def topic_ids(topics):
    out = []
    def walk(items):
        for t in items if isinstance(items, list) else []:
            if isinstance(t, dict):
                if t.get("id"):
                    out.append(t["id"])
                walk(t.get("child_topics", []))
    walk(topics)
    return out

def migrate_contract(doc: dict, relpath: str):
    src = deepcopy(doc)
    old_format = src.get("format", {}).get("format_version")
    old_status = src.get("status")

    doc = ensure_shape(deepcopy(src))

    # Every affected active contract is unlocked by the breaking 1.4 migration.
    if old_status in ACTIVE_STATUSES:
        doc["status"] = "unlocked"

    gaps = []

    ident = doc.get("identity") or {}
    for field in ("id", "name", "type", "version"):
        if field not in ident or ident.get(field) in (None, ""):
            gaps.append({
                "id": "IDENTITY_FIELD_MISSING",
                "field": f"identity.{field}",
                "severity": "hard_fail"
            })

    # Topic classification is semantic work. Never guess it from paths.
    tids = topic_ids(doc.get("topics", []))
    if old_status in ACTIVE_STATUSES and not tids:
        gaps.append({
            "id": "TOPIC_CLASSIFICATION_UNRESOLVED",
            "field": "topics",
            "severity": "hard_fail",
            "explanation": "Contract has no explicit 1.4 Topic classification. Do not infer Topic membership from the filesystem path."
        })

    notes = doc["prose"]["notes"]
    migration_note = (
        f"Contract Format migration: {old_format or 'unknown'} -> {FORMAT_VERSION}. "
        "Status remains unlocked until 1.4 Topic placement, reference resolution, "
        "semantic closure, explicit causality, round-trip and traceability validation pass."
    )
    if migration_note not in notes:
        notes.append(migration_note)

    return doc, {
        "path": relpath,
        "identity": ident.get("id"),
        "source_format_version": old_format,
        "target_format_version": FORMAT_VERSION,
        "source_status": old_status,
        "target_status": doc.get("status"),
        "topic_ids": tids,
        "gaps": gaps,
        "semantic_invention": False
    }

def validate_shape(doc: dict):
    missing = [k for k in REQUIRED_TOP_LEVEL if k not in doc]
    return missing

def main(repo_arg: str):
    repo = Path(repo_arg).resolve()
    source = repo / "canonical" / "json"
    if not source.is_dir():
        raise SystemExit(f"Not found: {source}")

    out = repo / "AIGMos_canonical_1.4_review"
    if out.exists():
        shutil.rmtree(out)
    target = out / "canonical" / "json"
    target.mkdir(parents=True)

    manifest = {
        "name": "AIGMos Canonical 1.4 Review Migration Manifest",
        "format_version": FORMAT_VERSION,
        "source_tree": str(source),
        "review_tree": str(target),
        "source_mutated": False,
        "rules": {
            "legacy": "copied only under review/history if encountered; never promoted to active authority",
            "active_contracts": "migrated to 1.4 and unlocked",
            "topics": "explicit only; never inferred from directory paths",
            "semantic_invention": "forbidden"
        },
        "contracts": [],
        "summary": {}
    }

    # Put the authoritative 1.4 format root in the clean review tree.
    bundled_format = Path(__file__).with_name("AIGMos_Canonical_Contract_Format_v1.4.0.json")
    shutil.copy2(bundled_format, target / "00_Contract_Format.json")

    for src in sorted(source.rglob("*")):
        rel = src.relative_to(source)
        rel_s = rel.as_posix()

        if src.is_dir():
            continue

        # The format root is replaced by the bundled 1.4 root above.
        if rel_s == "00_Contract_Format.json":
            manifest["contracts"].append({
                "path": rel_s,
                "identity": "AIGMos Canonical Contract Format",
                "source_format_version": "source",
                "target_format_version": FORMAT_ROOT_VERSION,
                "source_status": "source",
                "target_status": "locked",
                "topic_ids": [],
                "gaps": [],
                "semantic_invention": False,
                "action": "replaced_with_1.4_format_root"
            })
            continue

        # Keep non-JSON support files unchanged in the review tree.
        if src.suffix.lower() != ".json":
            dst = target / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            continue

        # Legacy/history is preserved as history, not normalized into active authority.
        if "legacy" in rel.parts:
            dst = target / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            manifest["contracts"].append({
                "path": rel_s,
                "action": "preserved_historical",
                "semantic_invention": False
            })
            continue

        try:
            doc = load_json(src)
        except Exception as e:
            manifest["contracts"].append({
                "path": rel_s,
                "action": "parse_failed",
                "gaps": [{
                    "id": "JSON_PARSE_FAILED",
                    "severity": "hard_fail",
                    "explanation": str(e)
                }]
            })
            continue

        if not isinstance(doc, dict):
            manifest["contracts"].append({
                "path": rel_s,
                "action": "non_contract_json_preserved",
                "semantic_invention": False
            })
            dst = target / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            continue

        migrated, record = migrate_contract(doc, rel_s)
        missing = validate_shape(migrated)
        if missing:
            record.setdefault("gaps", []).append({
                "id": "CF_MISSING_REQUIRED_FIELD",
                "severity": "hard_fail",
                "fields": missing
            })

        write_json(target / rel, migrated)
        record["action"] = "migrated_for_review"
        manifest["contracts"].append(record)

    records = manifest["contracts"]
    migrated = [r for r in records if r.get("action") == "migrated_for_review"]
    hard_gap_count = sum(
        1 for r in migrated for g in r.get("gaps", [])
        if g.get("severity") == "hard_fail"
    )
    topic_gap_count = sum(
        1 for r in migrated for g in r.get("gaps", [])
        if g.get("id") == "TOPIC_CLASSIFICATION_UNRESOLVED"
    )
    manifest["summary"] = {
        "records": len(records),
        "migrated_contracts": len(migrated),
        "hard_gaps": hard_gap_count,
        "topic_classification_gaps": topic_gap_count,
        "lock_eligible_contracts": sum(
            1 for r in migrated if not r.get("gaps")
        )
    }

    write_json(out / "migration_manifest.json", manifest)

    readme = f"""# AIGMos Canonical 1.4 Review Tree

This directory was generated as a clean parallel review tree.

- Source canonical tree was NOT modified.
- Target format: Contract Format {FORMAT_VERSION}.
- Active contracts are intentionally `unlocked`.
- Missing Topics are reported, not invented.
- Topic membership is never inferred from filesystem paths.
- `legacy/` remains historical.
- Review `migration_manifest.json` before replacing any live canonical tree.

Summary:
- migrated contracts: {manifest['summary']['migrated_contracts']}
- hard gaps: {manifest['summary']['hard_gaps']}
- unresolved Topic classifications: {manifest['summary']['topic_classification_gaps']}
- currently lock-eligible by this structural precheck: {manifest['summary']['lock_eligible_contracts']}

This builder performs a structural migration/precheck only.
Semantic Topic design, reference closure and explicit end-to-end flow completion
must be reviewed against authoritative AIGMos contracts before locking.
"""
    (out / "README_REVIEW.md").write_text(readme, encoding="utf-8")

    print(out)
    print(json.dumps(manifest["summary"], indent=2))

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python build_review_tree.py /path/to/AIGMos_docs")
    main(sys.argv[1])
